package com.cookandroid.final_exam;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class SubActivity extends AppCompatActivity {

    private RecycleAdapter adapter;
    private List<RecycleItem> fullItemList = new ArrayList<>();
    private List<RecycleItem> filteredList = new ArrayList<>();
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.subactivity_main); // SearchView와 RecyclerView 포함된 레이아웃

        searchView = findViewById(R.id.search_view_phone_book);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecycleAdapter(filteredList);
        recyclerView.setAdapter(adapter);

        initData();
        adapter.updateList(fullItemList); // 초기 전체 데이터 표시

        Button backtoMain = findViewById(R.id.backToMain);
        backtoMain.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(SubActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterData(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterData(newText);
                return true;
            }
        });
    }

    private void initData() {
        fullItemList.add(new RecycleItem("생수병", "PET", "플라스틱", "라벨 제거 후 배출"));
        fullItemList.add(new RecycleItem("종이컵", "종이+코팅", "일반쓰레기", "내용물 제거 후 배출"));
        fullItemList.add(new RecycleItem("유리병", "유리", "유리류", "병뚜껑 제거 후 배출"));
        fullItemList.add(new RecycleItem("치약 튜브", "플라스틱+알루미늄", "일반쓰레기", "껍질을 짜내고 배출"));
    }

    private void filterData(String keyword) {
        filteredList.clear();
        for (RecycleItem item : fullItemList) {
            if (item.getName().contains(keyword)) {
                filteredList.add(item);
            }
        }
        adapter.updateList(filteredList);
    }
}