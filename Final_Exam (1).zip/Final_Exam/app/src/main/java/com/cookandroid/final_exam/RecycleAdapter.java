package com.cookandroid.final_exam;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecycleAdapter extends RecyclerView.Adapter<RecycleAdapter.ViewHolder> {

    private List<RecycleItem> itemList;

    public RecycleAdapter(List<RecycleItem> itemList) {
        this.itemList = itemList;
    }

    public void updateList(List<RecycleItem> newList) {
        itemList = newList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, material, type, tip;

        public ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            material = itemView.findViewById(R.id.material);
            type = itemView.findViewById(R.id.type);
            tip = itemView.findViewById(R.id.tip);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_recycle, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        RecycleItem item = itemList.get(position);
        holder.name.setText("제품명: " + item.getName());
        holder.material.setText("재질: " + item.getMaterial());
        holder.type.setText("분류: " + item.getType());
        holder.tip.setText("배출 팁: " + item.getTip());
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }
}

