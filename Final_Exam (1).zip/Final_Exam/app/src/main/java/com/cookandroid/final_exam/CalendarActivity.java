package com.cookandroid.final_exam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class CalendarActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private TextView memoTextView;
    private Button writeMemoButton;
    private Button backButton;       // ← 추가: 뒤로가기 버튼 변수
    private SharedPreferences preferences;
    private static final String PREF_NAME = "CalendarMemos";
    private String selectedDateKey;  // “YYYY-MM-DD” 형태의 키

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        // 기존 레이아웃 뷰 연결
        calendarView    = findViewById(R.id.calendarView);
        memoTextView    = findViewById(R.id.memoTextView);
        writeMemoButton = findViewById(R.id.writeMemoButton);
        backButton      = findViewById(R.id.backButton);  // ← 뒤로가기 버튼 연결
        preferences     = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        // --- 뒤로가기 버튼 클릭 시 MainActivity로 돌아가기 ---
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(CalendarActivity.this, MainActivity.class);
            // 이미 MainActivity가 스택에 떠 있으면 그 위로 올라가고, 없으면 새로 생성
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });

        // --- 달력에서 날짜 선택 리스너 ---
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // month는 0-base(0=1월)이므로 +1 해 주고, 두 자릿수 포맷으로 변환
            int displayMonth = month + 1;
            String mm = (displayMonth < 10) ? "0" + displayMonth : String.valueOf(displayMonth);
            String dd = (dayOfMonth  < 10) ? "0" + dayOfMonth   : String.valueOf(dayOfMonth);
            selectedDateKey = year + "-" + mm + "-" + dd;

            // SharedPreferences에서 메모를 불러와 표시
            String memoForDate = preferences.getString(selectedDateKey, "");
            if (memoForDate.isEmpty()) {
                memoTextView.setText("해당 날짜에는 저장된 메모가 없습니다.");
            } else {
                memoTextView.setText(memoForDate);
            }
        });

        // --- 메모 작성/수정 버튼 클릭 리스너 ---
        writeMemoButton.setOnClickListener(v -> {
            if (selectedDateKey == null) {
                // 아직 날짜를 선택하지 않았다면 오늘 날짜를 키로 사용
                java.util.Calendar cal = java.util.Calendar.getInstance();
                int year  = cal.get(java.util.Calendar.YEAR);
                int month = cal.get(java.util.Calendar.MONTH) + 1; // 0 기반이므로 +1
                int day   = cal.get(java.util.Calendar.DAY_OF_MONTH);
                String mm = (month < 10) ? "0" + month : String.valueOf(month);
                String dd = (day   < 10) ? "0" + day   : String.valueOf(day);
                selectedDateKey = year + "-" + mm + "-" + dd;
            }
            showMemoDialog(selectedDateKey);
        });
    }

    private void showMemoDialog(String dateKey) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("메모 입력: " + dateKey);

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setText(preferences.getString(dateKey, ""));
        builder.setView(input);

        builder.setPositiveButton("저장", (dialog, which) -> {
            String memo = input.getText().toString().trim();
            SharedPreferences.Editor editor = preferences.edit();
            if (!memo.isEmpty()) {
                editor.putString(dateKey, memo);
            } else {
                editor.remove(dateKey); // 빈 문자열이면 해당 키 삭제
            }
            editor.apply();
            Toast.makeText(this, "메모 저장됨", Toast.LENGTH_SHORT).show();

            // 저장 후 화면 업데이트
            memoTextView.setText(memo.isEmpty()
                    ? "해당 날짜에는 저장된 메모가 없습니다."
                    : memo);
        });

        builder.setNegativeButton("취소", (dialog, which) -> dialog.cancel());
        builder.show();
    }
}
