package com.cookandroid.final_exam;

public class RecycleItem {
    private String name;
    private String material;
    private String type;
    private String tip;

    public RecycleItem(String name, String material, String type, String tip) {
        this.name = name;
        this.material = material;
        this.type = type;
        this.tip = tip;
    }

    public String getName() { return name; }
    public String getMaterial() { return material; }
    public String getType() { return type; }
    public String getTip() { return tip; }
}

