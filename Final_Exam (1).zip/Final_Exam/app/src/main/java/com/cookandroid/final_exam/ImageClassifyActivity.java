package com.cookandroid.final_exam;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;

import java.io.IOException;
import java.util.List;

public class ImageClassifyActivity extends AppCompatActivity {

    private static final int REQUEST_IMAGE_PICK = 1001;
    private static final int PERMISSION_REQUEST_READ_STORAGE = 2002;

    private ImageView imageView;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_classify);

        // 1) 레이아웃 내 뷰 연결
        imageView   = findViewById(R.id.imageView);
        resultText  = findViewById(R.id.resultText);
        Button selectImageButton = findViewById(R.id.selectImageButton);

        // 2) “이미지 선택하기” 버튼 클릭 시
        selectImageButton.setOnClickListener(v -> {
            // Android 6.0(API 23) 이상에서는 런타임 권한 체크가 필요
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ContextCompat.checkSelfPermission(
                        ImageClassifyActivity.this,
                        android.Manifest.permission.READ_EXTERNAL_STORAGE
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    // 권한이 허용되지 않았다면 요청
                    ActivityCompat.requestPermissions(
                            ImageClassifyActivity.this,
                            new String[]{ android.Manifest.permission.READ_EXTERNAL_STORAGE },
                            PERMISSION_REQUEST_READ_STORAGE
                    );
                    return;
                }
            }
            // 권한이 있으면 바로 이미지 피커 실행
            openImagePicker();
        });
    }

    // 3) 권한 요청 콜백
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_READ_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED) {
                openImagePicker();
            } else {
                Toast.makeText(this, "이미지 선택을 위해 저장소 권한이 필요합니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // 4) 이미지 피커 열기
    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_IMAGE_PICK);
    }

    // 5) 이미지 선택 결과 처리
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_PICK && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            if (imageUri == null) {
                Toast.makeText(this, "이미지 정보를 가져올 수 없습니다.", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                // 선택한 이미지를 Bitmap으로 변환
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(
                        this.getContentResolver(), imageUri);
                imageView.setImageBitmap(bitmap);

                // ML Kit 라벨링 수행
                detectImageLabels(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "이미지 로드 실패", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // 6) ML Kit를 이용해 이미지 라벨링 수행
    private void detectImageLabels(Bitmap bitmap) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        ImageLabeler labeler = ImageLabeling.getClient(
                new ImageLabelerOptions.Builder()
                        .setConfidenceThreshold(0.5f)   // 필요 시 조절
                        .build()
        );

        labeler.process(image)
                .addOnSuccessListener(labels -> {
                    StringBuilder resultBuilder = new StringBuilder();
                    for (ImageLabel label : labels) {
                        String text = label.getText();
                        float confidence = label.getConfidence();
                        resultBuilder.append(text)
                                .append(" (정확도: ")
                                .append(String.format("%.2f", confidence * 100))
                                .append("%)\n");
                    }
                    resultText.setText(resultBuilder.toString());
                })
                .addOnFailureListener(e -> {
                    e.printStackTrace();
                    resultText.setText("분석 실패");
                });
    }
}
